package com.mycompany.sistemaacademico;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DAO {
    public boolean existe(Usuario usuario)
            throws Exception{
        
        String sql = "SELECT * FROM " +
 "usuarios WHERE "
                +            "login = ? AND senha = ?";
        try(Connection conn = 
                ConexaoBD.obtemConexao();
            PreparedStatement ps =
                conn.prepareStatement(sql)
        ){
            ps.setString(1,usuario.getLogin());
            ps.setString(2,usuario.getSenha());
            try(ResultSet rs = ps.executeQuery()){
                return rs.next();   
            }
        }   
    }

    public void inserir(Curso curso) throws Exception{
        String sql = "INSERT INTO tb_curso(nome, tipo) VALUES (?,?)";
        
        try(Connection conn = ConexaoBD.obtemConexao();
                PreparedStatement ps = conn.prepareStatement(sql)){
            
            ps.setString(1, curso.getNome());
            ps.setString(2, curso.getTipo());
            ps.execute();
        }
    }

    public void atualizar(Curso curso) {
        // Primeiro, verifique se o curso com o ID especificado existe

        boolean cursoExiste = false;

        try {
            String sqlVerificacao = "SELECT * FROM tb_curso WHERE id = ?";
            Connection conn = ConexaoBD.obtemConexao();
            PreparedStatement pstmVerificacao = conn.prepareStatement(sqlVerificacao);
            pstmVerificacao.setInt(1, curso.getId());
            ResultSet rs = pstmVerificacao.executeQuery();

            if (rs.next()) {
                cursoExiste = true;
            }
        } catch (SQLException e) {
            // Trate a exceção conforme necessário
            e.printStackTrace();
        }

        // Se o curso não existir, exiba uma mensagem de erro e retorne
        if (!cursoExiste) {
            JOptionPane.showMessageDialog(null, "Curso não encontrado");
            return;
        } else {

        // Se o curso existir, proceda com a atualização
        String sql = "UPDATE tb_curso SET nome = ?, tipo = ? WHERE id = ?";
        try {
            Connection conn = ConexaoBD.obtemConexao();
            PreparedStatement pstm = conn.prepareStatement(sql);

            pstm.setString(1, curso.getNome());
            pstm.setString(2, curso.getTipo());
            pstm.setInt(3, curso.getId());

            pstm.executeUpdate();

            JOptionPane.showMessageDialog(null, "Curso atualizado");
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Não foi possível atualizar o curso: " + erro.getMessage());
            }
        }
    }

    public void excluir(Curso curso) {

        String sqlVerificacao = "select * from tb_curso where id = ?";
        boolean status = false;
        try {
            Connection conn = ConexaoBD.obtemConexao();
            PreparedStatement pstmVerificacao = conn.prepareStatement(sqlVerificacao);

            pstmVerificacao.setInt(1, curso.getId());

            ResultSet verif = pstmVerificacao.executeQuery();

            if (verif.next()) {
                status = true;
            }
        } catch (Exception error) {
        }
        if (!status) {
            JOptionPane.showMessageDialog(null, "Curso não encontrado");
            return;
        } else {

        String sql = "delete from tb_curso where id = ?";

        try {
            Connection conn = ConexaoBD.obtemConexao();
            PreparedStatement pstm = conn.prepareStatement(sql);

            pstm.setInt(1, curso.getId());

            pstm.execute();
            JOptionPane.showMessageDialog(null, "Curso excluido com sucesso!");
        } catch (Exception error) {
            JOptionPane.showMessageDialog(null, "Não foi possível excluir o curso: " + error.getMessage());

            }
        }
    }

}
    

   

